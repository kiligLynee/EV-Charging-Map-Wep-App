import { RouteObject } from "react-router-dom";
// import LayoutComp from "../layout-comp/LayoutComp";
// import NotFoundView from "../views/not-found-view/NotFoundView";
import React, { FC } from "react";
import { PageError } from "../pages/page-error";
import { NotFound } from "../pages/not-found";
import { MainLayout } from "../layout/main-layout";
// import ManageLayout from "../layout/manage-layout/ManageLayout";
// import QuestionLayout from "../layout/question-layout/QuestionLayout";

// 懒加载代码 vite 专用
const modules = import.meta.glob<boolean, string, { default: FC }>(
	"../pages/**/*.tsx"
);
const lazyLoad = (path: string) => {
	const key = `../pages/${path}.tsx`;
	// console.log("modulesLevel1: ", modules);
	// console.log("key: ", key);
	// console.log("modules[key]: ", modules[key]);

	const Comp = React.lazy(modules[key]);
	return (
		<React.Suspense fallback={<>加载中...</>}>
			<Comp />
		</React.Suspense>
	);
};

// lazyLoadL('home/index');

const publicRoutes: RouteObject[] = [
	{
		path: "/",
		element: <MainLayout />,
		errorElement: <PageError />,
		children: [
			{
				path: "",
				element: lazyLoad("home/index"),
			},
			{
				path: "login",
				element: lazyLoad("login/index"),
			},
			{
				path: "register",
				element: lazyLoad("register/index"),
			},
			{
				path: "us",
				element: lazyLoad("us/index"),
			},
			{
				path: "map-detail",
				element: lazyLoad("map-detail/index"),
			},
			{
				path: "*",
				element: <NotFound />,
			},
			// {
			//   path: "topic/:id",
			//   element: lazyLoad("topic-view/TopicView"),
			// },
			// {
			//   path: "user/:username",
			//   element: lazyLoad("user-view/UserView"),
			// },
		],
	},
];

export const routes: RouteObject[] = [...publicRoutes];

// -------------------------- 分割线 --------------------------

// 常用的路由常量
export const HOME_PATHNAME = "/";
export const LOGIN_PATHNAME = "/login";
export const REGISTER_PATHNAME = "/register";
export const MANAGE_INDEX_PATHNAME = "/manage/list";

export function isLoginOrRegister(pathname: string) {
	return [LOGIN_PATHNAME, REGISTER_PATHNAME].includes(pathname);
}
export function isNoNeedLogin(pathname: string) {
	return [LOGIN_PATHNAME, REGISTER_PATHNAME].includes(pathname);
}
